#include<cstdio>
#include<cstring>
#include<string>
#include<iostream>
#include<cstdlib>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
#include<list>
#include<map>
#include<set>
#include<climits>
#include<cmath>
#include<sstream>

using namespace std;

#define FASTER ios_base::sync_with_stdio(0);

typedef long long int ll;
int grid[3005][3005];
bool present[3005][3005];

int main() {

  FASTER;
  ll t, ans, r, c, k, a, b;
  cin >> t;  
  for(int ko = 1; ko <= t; ko++) {
    cin >> r >> c >> k;
    for(int i = 0; i < r; i++) {
      for(int j = 0; j < c; j++) {
        grid[i][j] = 1;
        present[i][j] = false;
      }
    }
    for(int i = 0; i < k; i++) {
      cin >> a >> b;
      grid[a][b] = 0;
      present[a][b] = true;
    }
    ans = 0;
    for(int i = 0; i < r; i++) {
      if (!present[i][0]) {
        grid[i][0] = 1;
        ans++;
      }
    }
    for(int i = 1; i < c; i++) {
      if (!present[0][i]) {
        grid[0][i] = 1;
        ans++;
      }
    }
    for(int i = 1; i < r; i++) {
      for(int j = 1; j < c; j++) {
        if (!present[i][j]) {
          grid[i][j] = min(grid[i - 1][j], min(grid[i][j - 1], grid[i - 1][j - 1])) + 1;
          ans += grid[i][j];
        }
      }
    }
    cout << "Case #" << ko << ": " << ans << endl;
  }
  return 0;
}
